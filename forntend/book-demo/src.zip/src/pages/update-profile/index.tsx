import React from "react";
import { Typography } from "@material-ui/core";
import { UpdateProfileModel } from "../../models/UserModel";

const UpdateProfile = () => {
    return (
        <>
            <Typography variant="h1">UpdateProfile</Typography>
        </>
    );
};

export default UpdateProfile;
